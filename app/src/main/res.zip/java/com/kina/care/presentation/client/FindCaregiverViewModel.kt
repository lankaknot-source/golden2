package com.kina.care.presentation.client

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.FirebaseFirestore
import com.kina.care.domain.model.Review
import com.kina.care.domain.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FindCaregiverUiState(
    val isLoading: Boolean = true,
    val caregivers: List<User> = emptyList(),
    val errorMessage: String? = null
)

class FindCaregiverViewModel : ViewModel() {
    private val firestore = FirebaseFirestore.getInstance()

    private val _uiState = MutableStateFlow(FindCaregiverUiState())
    val uiState: StateFlow<FindCaregiverUiState> = _uiState.asStateFlow()

    private var allCaregivers: List<User> = emptyList()

    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("All")

    private val _reviewsState = MutableStateFlow<List<Review>>(emptyList())
    val reviewsState: StateFlow<List<Review>> = _reviewsState.asStateFlow()

    var isReviewsLoading = MutableStateFlow(false)

    init {
        fetchCaregiversFromFirebase()
    }

    private fun fetchCaregiversFromFirebase() {
        viewModelScope.launch {
            try {
                val snapshot = firestore.collection("users")
                    .whereEqualTo("role", "CAREGIVER")
                    .get()
                    .await()

                val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

                val list = snapshot.documents.mapNotNull { it.toObject(User::class.java) }
                    .filter { it.isVerified && !it.isBusy && !it.onLeaveDates.contains(todayStr) }
                    .sortedByDescending { it.rating }

                allCaregivers = list
                applyFilters()

            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = e.localizedMessage)
            }
        }
    }

    // 🌟 Fix: Error එක මඟහරවා ගැනීමට Screen එකේ භාවිතා වන නමම යෙදීම
    fun updateSearchQuery(query: String) {
        searchQuery.value = query
        applyFilters()
    }

    // 🌟 Fix: Category එක වෙනස් කිරීමට අවශ්‍ය Function එක
    fun updateCategory(category: String) {
        selectedCategory.value = category
        applyFilters()
    }

    private fun applyFilters() {
        var filteredList = allCaregivers

        val query = searchQuery.value.trim()
        if (query.isNotEmpty()) {
            filteredList = filteredList.filter {
                it.name.contains(query, ignoreCase = true) ||
                        it.address.contains(query, ignoreCase = true)
            }
        }

        val category = selectedCategory.value
        if (category != "All") {
            filteredList = filteredList.filter { it.categories.contains(category) }
        }

        _uiState.value = _uiState.value.copy(isLoading = false, caregivers = filteredList)
    }

    fun fetchReviewsForCaregiver(caregiverId: String) {
        viewModelScope.launch {
            isReviewsLoading.value = true
            try {
                val snapshot = firestore.collection("reviews")
                    .whereEqualTo("caregiverId", caregiverId)
                    .get()
                    .await()

                val reviews = snapshot.documents.mapNotNull { it.toObject(Review::class.java) }
                    .sortedByDescending { it.timestamp }

                _reviewsState.value = reviews
            } catch (e: Exception) {
                e.printStackTrace()
                _reviewsState.value = emptyList()
            } finally {
                isReviewsLoading.value = false
            }
        }
    }

    fun clearReviews() {
        _reviewsState.value = emptyList()
    }
}