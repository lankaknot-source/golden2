package com.kina.care.presentation.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    bookingId: String,
    onBackClick: () -> Unit,
    viewModel: ChatViewModel = viewModel()
) {
    val messages by viewModel.messages.collectAsState()
    var inputText by remember { mutableStateOf("") }

    LaunchedEffect(bookingId) {
        viewModel.loadMessages(bookingId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("පණිවිඩ (Messages)", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBackClick) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0EA5E9))
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Type a message...") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF0EA5E9))
                )
                Spacer(modifier = Modifier.width(8.dp))
                FloatingActionButton(
                    onClick = {
                        viewModel.sendMessage(bookingId, inputText)
                        inputText = ""
                    },
                    containerColor = Color(0xFF0EA5E9),
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(50.dp)
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send")
                }
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().background(Color(0xFFF1F5F9)).padding(paddingValues)) {
            if (messages.isEmpty()) {
                Text(
                    "රැකියාවට අදාළව පණිවිඩයක් යවන්න.\n(මෙම පණිවිඩ රැකියාව අවසන් වූ පසු මැකී යනු ඇත.)",
                    color = Color.Gray,
                    modifier = Modifier.align(Alignment.Center),
                    textAlign = TextAlign.Center
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
                    reverseLayout = false
                ) {
                    items(messages) { msg ->
                        val isMe = msg.senderId == viewModel.currentUserId
                        val bgColor = if (isMe) Color(0xFFE0F2FE) else Color.White
                        val align = if (isMe) Alignment.End else Alignment.Start

                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalAlignment = align) {
                            if (!isMe) {
                                Text(msg.senderName, fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(bottom = 2.dp, start = 4.dp))
                            }
                            Card(
                                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = if(isMe) 16.dp else 4.dp, bottomEnd = if(isMe) 4.dp else 16.dp),
                                colors = CardDefaults.cardColors(containerColor = bgColor),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(msg.text, fontSize = 15.sp, color = Color(0xFF1E293B))
                                    Text(
                                        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(msg.timestamp)),
                                        fontSize = 10.sp, color = Color.Gray,
                                        modifier = Modifier.align(Alignment.End).padding(top=4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}